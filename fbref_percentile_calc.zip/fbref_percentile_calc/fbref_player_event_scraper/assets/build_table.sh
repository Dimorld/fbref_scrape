#! /usr/bin/env bash
#
#            DEBUGGING
#
trap 'printf "\n" ; s=$?; echo >&2 "$0: Exit code on line "$LINENO": $BASH_COMMAND"; exit $s ;' ERR
set -eou pipefail
#set -x


raw_html="${1}"

(awk -f table_header_1.awk "${raw_html}" ; awk -f table_header_2 "${raw_html}" ; awk -f table_body.awk "${raw_html}")

exit 0
