### NOTES 

The data values presented in the whaterver.dat file are in the
same form as in the website, at the moment of this being typed,
the values ARE NOT IN THE FORM OF PER 90



### USAGE

Read the comments in ./scraper.sh, then run/execute ./scraper.sh



### CODE TO GET COMPETITION IDs and NAMES

Code to create the list:

    awk 'BEGIN{FS="comps"}/<tr class=/{split($2,arr,"/") ; split(arr[4], arr2, "\"") ; gsub(/-Seasons/,"",arr2[1]); gsub(/^[ ]/,"",arr[10]); $1=arr[10] ; print $1,arr2[1],arr[2];1}' Football\ Competitions\ FBref.com.html | sort -k1,2 | awk '{$1=$1; print "\""$0"\""}

Apply the previous awk code to an html file containing the code from https://fbref.com/en/comps, and them remove the " , you are free to do it to the best of your abilities

Code to create the contents inside the autocompletion directory
    
    cat ../competition.dat | xargs -0 -d "\n" touch

Last time the list was updated ( code executed 2024/02/02 )

list available in `competitions.dat`



### NAME AND IDs OF THE STATS CAPTURED BY FBREF

Available in the file `stat_events.dat`, you update data manually

last time updated 2024/02/03 
