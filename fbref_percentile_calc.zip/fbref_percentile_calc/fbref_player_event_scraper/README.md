## Things To Keep in Mind

 * The set of scripts in this project downloads the footballers' data available in fbref.com
 * scraper file is the main dog, it uses the files in the assets directory to download, and extract the data from fbref.com, before executing it, read its comments
 * The assets directory contains three awk files that are executed by build_table.sh, build_table.sh is executed by scraper, the files are in charge of extracting the data from an html file.
 * The file competitions.dat is the list of all the soccer tournaments for which fbref.com has data available
 * The file stat_events.dat contains the type of data provided by fbref.com, i.e., passing, goal creating actions
 * The directory auto_completion contains several empty files, the names of the files correspond to the leagues for which fbref.com has data avaible
 * head_info bash script is to be executed with a raw data file name as an argument, it will show you the raw data file's numbers and names
 
## Raw Files Notes

 * The scraper file produces raw data files that include two header lines
 * The files produced by scraper have comma separated fields
 * The files created present the data as it is in the webpage, so the data will have the same limitations
 * The scraper file removes the comma character if it is present in the footballer's position field
 * The scraper produces raw files with the same name for Advanced Goalkeeping and Regular Goalkeeping, so, when requesting any of them, manually rename them to be able to differentiate them, else one will overwrite the other
 * The same approach as above for passing and passing types
 




